from distutils.core import setup                                                                                  

setup(
    name='acidipy',
    version='0.9.5',
    py_modules=['acidipy'],
    author='Hyechurn Jang',
    author_email='hyjang@cisco.com',
    url='https://github.com/HyechurnJang/acidipy',
    description='Acidipy',
)
